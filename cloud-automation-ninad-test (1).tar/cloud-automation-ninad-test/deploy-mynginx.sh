#!/bin/bash

/home/gitlab-runner/builds/NcM5RHfU/0/navify-analytics/cloud-automation/kubectl apply -f run-my-nginx.yaml

/home/gitlab-runner/builds/NcM5RHfU/0/navify-analytics/cloud-automation/kubectl get pods

/home/gitlab-runner/builds/NcM5RHfU/0/navify-analytics/cloud-automation/kubectl expose deployment/my-nginx --port=80 --target-port=80 --name=my-nginx-service --type=LoadBalancer

/home/gitlab-runner/builds/NcM5RHfU/0/navify-analytics/cloud-automation/kubectl get svc
